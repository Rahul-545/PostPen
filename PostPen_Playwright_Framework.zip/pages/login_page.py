from playwright.sync_api import Page

class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.email_input = page.locator("//input[@id='email']")
        self.password_input = page.locator("//input[@id='password']")
        self.submit_button = page.locator("//button[@type='submit']")

    def load(self):
        self.page.goto("https://app.postpen.ai/auth")

    def login(self, email: str, password: str):
        self.email_input.fill(email)
        self.password_input.fill(password)
        self.submit_button.click()