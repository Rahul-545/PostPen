from pages.login_page import LoginPage

def test_login_valid_user(page):
    login_page = LoginPage(page)
    login_page.load()
    login_page.login("sparxqa@gmail.com", "Password@2")

    page.wait_for_url("**/dashboard", timeout=5000)
    assert "dashboard" in page.url